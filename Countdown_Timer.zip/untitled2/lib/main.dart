import 'package:flutter/material.dart';
import 'dart:async';

void main() {
  runApp(CountdownTimerApp());
}

class CountdownTimerApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: CountdownTimerScreen(),
    );
  }
}

class CountdownTimerScreen extends StatefulWidget {
  @override
  _CountdownTimerScreenState createState() => _CountdownTimerScreenState();
}

class _CountdownTimerScreenState extends State<CountdownTimerScreen> {
  int _selectedMinutes = 1; // Default countdown time
  int _remainingSeconds = 0;
  Timer? _timer;
  bool _isCountingDown = false;
  bool _isPaused = false;

  @override
  void initState() {
    super.initState();
  }

  void _startTimer() {
    if (_timer != null) {
      _timer!.cancel();
    }

    setState(() {
      _remainingSeconds = _selectedMinutes * 60;
      _isCountingDown = true;
      _isPaused = false;
    });

    _timer = Timer.periodic(Duration(seconds: 1), (timer) {
      setState(() {
        if (_remainingSeconds > 0) {
          _remainingSeconds--;
        } else {
          _timer!.cancel();
          _isCountingDown = false;
          _showCompletionAlert();
        }
      });
    });
  }

  void _pauseTimer() {
    if (_timer != null) {
      _timer!.cancel();
    }
    setState(() {
      _isPaused = true;
      _isCountingDown = false;
    });
  }

  void _resumeTimer() {
    setState(() {
      _isCountingDown = true;
      _isPaused = false;
    });

    _timer = Timer.periodic(Duration(seconds: 1), (timer) {
      setState(() {
        if (_remainingSeconds > 0) {
          _remainingSeconds--;
        } else {
          _timer!.cancel();
          _isCountingDown = false;
          _showCompletionAlert();
        }
      });
    });
  }

  void _stopTimer() {
    if (_timer != null) {
      _timer!.cancel();
    }
    setState(() {
      _isCountingDown = false;
      _isPaused = false;
    });
  }

  void _showCompletionAlert() {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text('Time\'s Up!'),
          content: Text('The countdown has finished.'),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: Text('OK'),
            ),
          ],
        );
      },
    );
  }

  String _formatTime(int totalSeconds) {
    int minutes = totalSeconds ~/ 60;
    int seconds = totalSeconds % 60;
    return '${minutes.toString().padLeft(2, '0')}:${seconds.toString().padLeft(2, '0')}';
  }

  void _navigateToSettings() {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => SettingsPage()),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Countdown Timer'),
        actions: [
          IconButton(
            icon: Icon(Icons.settings),
            onPressed: _navigateToSettings,
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              'Set Timer (Minutes):',
              style: TextStyle(fontSize: 20),
            ),
            Slider(
              value: _selectedMinutes.toDouble(),
              min: 1,
              max: 60,
              divisions: 59,
              label: '$_selectedMinutes min',
              onChanged: !_isCountingDown && !_isPaused
                  ? (value) {
                setState(() {
                  _selectedMinutes = value.toInt();
                });
              }
                  : null,
            ),
            SizedBox(height: 20),
            Text(
              'Time Remaining: ${_formatTime(_remainingSeconds)}',
              style: TextStyle(fontSize: 36, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 20),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                ElevatedButton(
                  onPressed: !_isCountingDown ? _startTimer : null,
                  child: Text('Start'),
                ),
                SizedBox(width: 10),
                ElevatedButton(
                  onPressed: _isCountingDown ? _pauseTimer : null,
                  child: Text('Pause'),
                  style: ElevatedButton.styleFrom(backgroundColor: Colors.orange),
                ),
                SizedBox(width: 10),
                ElevatedButton(
                  onPressed: _isPaused ? _resumeTimer : null,
                  child: Text('Resume'),
                  style: ElevatedButton.styleFrom(backgroundColor: Colors.green),
                ),
                SizedBox(width: 10),
                ElevatedButton(
                  onPressed: _isCountingDown || _isPaused ? _stopTimer : null,
                  child: Text('Stop'),
                  style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  @override
  void dispose() {
    if (_timer != null) {
      _timer!.cancel();
    }
    super.dispose();
  }
}

class SettingsPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Settings'),
      ),
      body: Center(
        child: Text(
          'Settings Page (Add custom options here)',
          style: TextStyle(fontSize: 18),
        ),
      ),
    );
  }
}
